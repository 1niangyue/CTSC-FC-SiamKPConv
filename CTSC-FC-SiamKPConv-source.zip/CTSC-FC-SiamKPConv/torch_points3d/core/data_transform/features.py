from typing import List, Optional
from tqdm.auto import tqdm as tq
import itertools
import numpy as np
import math
import re
import torch
import random
from torch.nn import functional as F
from functools import partial

from torch_geometric.nn import fps, radius, knn, voxel_grid
from torch_geometric.nn.pool.consecutive import consecutive_cluster
from torch_geometric.nn.pool.pool import pool_pos, pool_batch
from torch_scatter import scatter_add, scatter_mean
from torch_geometric.data import Data, Batch
from torch_points3d.datasets.multiscale_data import MultiScaleData
from torch_points3d.utils.transform_utils import SamplingStrategy
from torch_points3d.utils.config import is_list
from torch_points3d.utils import is_iterable
from torch_points3d.utils.geometry import euler_angles_to_rotation_matrix
from torch.cuda.amp import autocast


class CrossTemporalFeatures(object):
    """Compute compact, symmetric cross-temporal descriptors for a cloud pair.

    The full ``ctsc`` vector is the concatenation of three independently
    selectable groups: ``ct_geom`` (4-D), ``ct_height`` (3-D), and
    ``ct_reliability`` (3-D).  Every group is robustly clipped and standardized
    per epoch/direction so the descriptors can be concatenated directly to the
    existing Siamese input.
    """

    def __init__(self, k=8, scale=0.5, clip=5.0, chunk_size=200000, eps=1e-6):
        self.k = int(k)
        self.scale = float(scale)
        self.clip = float(clip)
        self.chunk_size = int(chunk_size)
        self.eps = float(eps)

    def _query(self, tree, points, k):
        distances, indices = [], []
        for start in range(0, points.shape[0], self.chunk_size):
            d, i = tree.query(points[start:start + self.chunk_size], k=k)
            distances.append(d)
            indices.append(i)
        return np.concatenate(distances, axis=0), np.concatenate(indices, axis=0)

    def _standardize(self, values):
        values = np.nan_to_num(values, nan=0.0, posinf=self.clip, neginf=-self.clip)
        mean = values.mean(axis=0, keepdims=True)
        std = values.std(axis=0, keepdims=True)
        values = (values - mean) / np.maximum(std, self.eps)
        return np.clip(values, -self.clip, self.clip) * self.scale

    def _one_direction(self, source, target, source_tree, target_tree,
                       source_xy_tree, target_xy_tree, reverse_nn):
        n_cross = min(self.k, target.shape[0])
        n_self = min(self.k + 1, source.shape[0])
        d3, i3 = self._query(target_tree, source, n_cross)
        dxy, ixy = self._query(target_xy_tree, source[:, :2], n_cross)
        dself, _ = self._query(source_tree, source, n_self)

        # Geometry: nearest displacement plus neighbourhood ambiguity.
        geom = np.stack((d3[:, 0], d3.mean(1), d3.std(1), dxy[:, 0]), axis=1)

        # Directional height statistics from XY correspondences are robust to
        # sloped facades and preserve the sign of construction/removal.
        dz = target[ixy, 2] - source[:, None, 2]
        q25, med, q75 = np.quantile(dz, (0.25, 0.5, 0.75), axis=1)
        height = np.stack((med, np.median(np.abs(dz), axis=1), q75 - q25), axis=1)

        self_scale = dself[:, -1]
        cross_scale = d3[:, -1]
        scale_ratio = np.log((self_scale + self.eps) / (cross_scale + self.eps))
        mutual = (reverse_nn[i3[:, 0]] == np.arange(source.shape[0])).astype(np.float32)
        confidence = np.exp(-d3[:, 0] / (self_scale + cross_scale + self.eps))
        reliability = np.stack((scale_ratio, mutual, confidence), axis=1)
        return self._standardize(geom), self._standardize(height), self._standardize(reliability)

    @staticmethod
    def _set_features(data, geom, height, reliability):
        dtype = data.pos.dtype
        device = data.pos.device
        data.ct_geom = torch.as_tensor(geom, dtype=dtype, device=device)
        data.ct_height = torch.as_tensor(height, dtype=dtype, device=device)
        data.ct_reliability = torch.as_tensor(reliability, dtype=dtype, device=device)
        data.ctsc = torch.cat((data.ct_geom, data.ct_height, data.ct_reliability), dim=1)

    def __call__(self, data0, data1):
        # sklearn's KDTree is already a project dependency and is substantially
        # more memory-friendly here than materialising a full torch distance map.
        from sklearn.neighbors import KDTree

        p0 = data0.pos.detach().cpu().numpy().astype(np.float64, copy=False)
        p1 = data1.pos.detach().cpu().numpy().astype(np.float64, copy=False)
        if p0.shape[0] == 0 or p1.shape[0] == 0:
            raise ValueError("Cross-temporal features require two non-empty point clouds")

        t0, t1 = KDTree(p0), KDTree(p1)
        xy0, xy1 = KDTree(p0[:, :2]), KDTree(p1[:, :2])
        _, nn01 = self._query(t1, p0, 1)
        _, nn10 = self._query(t0, p1, 1)
        g0, h0, r0 = self._one_direction(p0, p1, t0, t1, xy0, xy1, nn10[:, 0])
        g1, h1, r1 = self._one_direction(p1, p0, t1, t0, xy1, xy0, nn01[:, 0])
        self._set_features(data0, g0, h0, r0)
        self._set_features(data1, g1, h1, r1)
        return data0, data1

    def __repr__(self):
        return "{}(k={}, scale={}, clip={})".format(
            self.__class__.__name__, self.k, self.scale, self.clip
        )

class Random3AxisRotation(object):
    """
    Rotate pointcloud with random angles along x, y, z axis

    The angles should be given `in degrees`.

    Parameters
    -----------
    apply_rotation: bool:
        Whether to apply the rotation
    rot_x: float
        Rotation angle in degrees on x axis
    rot_y: float
        Rotation anglei n degrees on y axis
    rot_z: float
        Rotation angle in degrees on z axis
    """

    def __init__(self, apply_rotation: bool = True, rot_x: float = None, rot_y: float = None, rot_z: float = None):
        self._apply_rotation = apply_rotation
        if apply_rotation:
            if (rot_x is None) and (rot_y is None) and (rot_z is None):
                raise Exception("At least one rot_ should be defined")

        self._rot_x = np.abs(rot_x) if rot_x else 0
        self._rot_y = np.abs(rot_y) if rot_y else 0
        self._rot_z = np.abs(rot_z) if rot_z else 0

        self._degree_angles = [self._rot_x, self._rot_y, self._rot_z]

    def generate_random_rotation_matrix(self):
        thetas = torch.zeros(3, dtype=torch.float)
        for axis_ind, deg_angle in enumerate(self._degree_angles):
            if deg_angle > 0:
                rand_deg_angle = random.random() * 2 * deg_angle - deg_angle
                rand_radian_angle = float(rand_deg_angle * np.pi) / 180.0
                thetas[axis_ind] = rand_radian_angle
        return euler_angles_to_rotation_matrix(thetas, random_order=True)

    def __call__(self, data):
        if self._apply_rotation:
            pos = data.pos.float()
            M = self.generate_random_rotation_matrix()
            data.pos = pos @ M.T
            if getattr(data, "norm", None) is not None:
                data.norm = data.norm.float() @ M.T
        return data

    def __repr__(self):
        return "{}(apply_rotation={}, rot_x={}, rot_y={}, rot_z={})".format(
            self.__class__.__name__, self._apply_rotation, self._rot_x, self._rot_y, self._rot_z
        )


class RandomTranslation(object):
    """
    random translation
    Parameters
    -----------
    delta_min: list
        min translation
    delta_max: list
        max translation
    """

    def __init__(self, delta_max: List = [1.0, 1.0, 1.0], delta_min: List = [-1.0, -1.0, -1.0]):
        self.delta_max = torch.tensor(delta_max)
        self.delta_min = torch.tensor(delta_min)

    def __call__(self, data):
        pos = data.pos
        trans = torch.rand(3) * (self.delta_max - self.delta_min) + self.delta_min
        data.pos = pos + trans
        return data

    def __repr__(self):
        return "{}(delta_min={}, delta_max={})".format(self.__class__.__name__, self.delta_min, self.delta_max)


class AddFeatsByKeys(object):
    """This transform takes a list of attributes names and if allowed, add them to x

    Example:

        Before calling "AddFeatsByKeys", if data.x was empty

        - transform: AddFeatsByKeys
          params:
              list_add_to_x: [True, True]
              feat_names: ['normal', 'elevation']
              input_nc_feats: [3, 1]

        After calling "AddFeatsByKeys", data.x contains normals and elevation (3 + 1 = 4 channels).
        A declared normal dimension other than 3 would raise an exception.

    Paremeters
    ----------
    list_add_to_x: List[bool]
        For each boolean within list_add_to_x, control if the associated feature is going to be concatenated to x
    feat_names: List[str]
        The list of features within data to be added to x
    input_nc_feats: List[int], optional
        If provided, evaluate the dimension of the associated feature shape[-1] found using feat_names and this provided value. It allows to make sure feature dimension didn't change
    stricts: List[bool], optional
        Recommended to be set to list of True. If True, it will raise an Exception if feat isn't found or dimension doesn t match.
    delete_feats: List[bool], optional
        Wether we want to delete the feature from the data object. List length must match teh number of features added.
    """

    def __init__(
        self,
        list_add_to_x: List[bool],
        feat_names: List[str],
        input_nc_feats: List[Optional[int]] = None,
        stricts: List[bool] = None,
        delete_feats: List[bool] = None,
    ):

        self._feat_names = feat_names
        self._list_add_to_x = list_add_to_x
        self._delete_feats = delete_feats
        if self._delete_feats:
            assert len(self._delete_feats) == len(self._feat_names)
        from torch_geometric.transforms import Compose

        num_names = len(feat_names)
        if num_names == 0:
            raise Exception("Expected to have at least one feat_names")

        assert len(list_add_to_x) == num_names

        if input_nc_feats:
            assert len(input_nc_feats) == num_names
        else:
            input_nc_feats = [None for _ in range(num_names)]

        if stricts:
            assert len(stricts) == num_names
        else:
            stricts = [True for _ in range(num_names)]

        transforms = [
            AddFeatByKey(add_to_x, feat_name, input_nc_feat=input_nc_feat, strict=strict)
            for add_to_x, feat_name, input_nc_feat, strict in zip(list_add_to_x, feat_names, input_nc_feats, stricts)
        ]

        self.transform = Compose(transforms)

    def __call__(self, data):
        data = self.transform(data)
        if self._delete_feats:
            for feat_name, delete_feat in zip(self._feat_names, self._delete_feats):
                if delete_feat:
                    delattr(data, feat_name)
        return data

    def __repr__(self):
        msg = ""
        for f, a in zip(self._feat_names, self._list_add_to_x):
            msg += "{}={}, ".format(f, a)
        return "{}({})".format(self.__class__.__name__, msg[:-2])


class AddFeatByKey(object):
    """This transform is responsible to get an attribute under feat_name and add it to x if add_to_x is True

    Paremeters
    ----------
    add_to_x: bool
        Control if the feature is going to be added/concatenated to x
    feat_name: str
        The feature to be found within data to be added/concatenated to x
    input_nc_feat: int, optional
        If provided, check if feature last dimension maches provided value.
    strict: bool, optional
        Recommended to be set to True. If False, it won't break if feat isn't found or dimension doesn t match. (default: ``True``)
    """

    def __init__(self, add_to_x, feat_name, input_nc_feat=None, strict=True):

        self._add_to_x: bool = add_to_x
        self._feat_name: str = feat_name
        self._input_nc_feat = input_nc_feat
        self._strict: bool = strict

    def __call__(self, data: Data):
        if not self._add_to_x:
            return data
        feat = getattr(data, self._feat_name, None)
        if feat is None:
            if self._strict:
                raise Exception("Data should contain the attribute {}".format(self._feat_name))
            else:
                return data
        else:
            if self._input_nc_feat:
                feat_dim = 1 if feat.dim() == 1 else feat.shape[-1]
                if self._input_nc_feat != feat_dim and self._strict:
                    raise Exception("The shape of feat: {} doesn t match {}".format(feat.shape, self._input_nc_feat))
            x = getattr(data, "x", None)
            if x is None:
                if self._strict and data.pos.shape[0] != feat.shape[0]:
                    raise Exception("We expected to have an attribute x")
                if feat.dim() == 1:
                    feat = feat.unsqueeze(-1)
                data.x = feat
            else:
                if x.shape[0] == feat.shape[0]:
                    if x.dim() == 1:
                        x = x.unsqueeze(-1)
                    if feat.dim() == 1:
                        feat = feat.unsqueeze(-1)
                    data.x = torch.cat([x, feat], dim=-1)
                else:
                    raise Exception(
                        "The tensor x and {} can't be concatenated, x: {}, feat: {}".format(
                            self._feat_name, x.pos.shape[0], feat.pos.shape[0]
                        )
                    )
        return data

    def __repr__(self):
        return "{}(add_to_x: {}, feat_name: {}, strict: {})".format(
            self.__class__.__name__, self._add_to_x, self._feat_name, self._strict
        )


def compute_planarity(eigenvalues):
    r"""
    compute the planarity with respect to the eigenvalues of the covariance matrix of the pointcloud
    let
    :math:`\lambda_1, \lambda_2, \lambda_3` be the eigenvalues st:

    .. math::
        \lambda_1 \leq \lambda_2 \leq \lambda_3

    then planarity is defined as:

    .. math::
        planarity = \frac{\lambda_2 - \lambda_1}{\lambda_3}
    """

    return (eigenvalues[1] - eigenvalues[0]) / eigenvalues[2]


class NormalFeature(object):
    """
    add normal as feature. if it doesn't exist, compute normals
    using PCA
    """

    def __call__(self, data):
        if getattr(data, "norm", None) is None:
            raise NotImplementedError("TODO: Implement normal computation")

        norm = data.norm
        if data.x is None:
            data.x = norm
        else:
            data.x = torch.cat([data.x, norm], -1)
        return data


class PCACompute(object):
    r"""
    compute `Principal Component Analysis <https://en.wikipedia.org/wiki/Principal_component_analysis>`__ of a point cloud :math:`x_1,\dots, x_n`.
    It computes the eigenvalues and the eigenvectors of the matrix :math:`C` which is the covariance matrix of the point cloud:

    .. math::
        x_{centered} &= \frac{1}{n} \sum_{i=1}^n x_i

        C &= \frac{1}{n} \sum_{i=1}^n (x_i - x_{centered})(x_i - x_{centered})^T

    store the eigen values and the eigenvectors in data.
    in eigenvalues attribute and eigenvectors attributes.
    data.eigenvalues is a tensor :math:`(\lambda_1, \lambda_2, \lambda_3)` such that :math:`\lambda_1 \leq \lambda_2 \leq \lambda_3`.

    data.eigenvectors is a 3 x 3 matrix such that the column are the eigenvectors associated to their eigenvalues
    Therefore, the first column of data.eigenvectors estimates the normal at the center of the pointcloud.
    """

    def __call__(self, data):
        pos_centered = data.pos - data.pos.mean(axis=0)
        cov_matrix = pos_centered.T.mm(pos_centered) / len(pos_centered)
        eig, v = torch.symeig(cov_matrix, eigenvectors=True)
        data.eigenvalues = eig
        data.eigenvectors = v
        return data

    def __repr__(self):
        return "{}()".format(self.__class__.__name__)


class AddOnes(object):
    """
    Add ones tensor to data
    """

    def __call__(self, data):
        num_nodes = data.pos.shape[0]
        data.ones = torch.ones((num_nodes, 1)).float()
        return data

    def __repr__(self):
        return "{}()".format(self.__class__.__name__)


class XYZFeature(object):

    def __call__(self, data):
        data.pos_f = data.pos[:, 2:3].clone()
        return data

    def __repr__(self):
        return "{}(axis={})".format(self.__class__.__name__, self._axis_names)




class FPFHCompute(object):
    """
    计算快速点特征直方图（Fast Point Feature Histograms, FPFH）。
    该类通过计算每个点的简化特征（SPFH），并通过加权求和组合邻域点的 SPFH 得到 FPFH。
    """
    def __init__(self, k=25, num_bins=15, device='cuda', chunk=4096):
        self.k = k
        self.num_bins = num_bins
        self.device = device
        self.chunk = chunk
        """
        初始化 FPFHCompute 类。

        参数:
        k (int): 用于计算邻域的近邻数量。
        num_bins (int): 直方图的 bin 数量。
        """

    def compute_spfh(self, data, p_idx, neighbor_indices):
        """
        计算单个点的简化特征（SPFH）。

        参数:
        data (torch_geometric.data.Data): 包含点云数据的对象。
        p_idx (int): 中心点的索引。
        neighbor_indices (torch.Tensor): 中心点的邻域点索引。

        返回:
        torch.Tensor: 中心点的 SPFH。
        """
        pos = data.pos
        nei = pos[neighbor_indices] - pos[p_idx]  # [k, 3]

        # 逐点邻域法线
        cov = torch.bmm(nei.unsqueeze(2), nei.unsqueeze(1)).sum(0) / self.k
        _, v = torch.linalg.eigh(cov)
        u = v[:, 0].unsqueeze(0).expand(nei.size(0), -1)  # [k, 3]

        d = torch.norm(nei, dim=1, keepdim=True)
        diff_norm = nei / d

        u_expanded = u.expand_as(diff_norm)  # [chunk, k, 3]

        # 计算角度

        cross_prod = torch.cross(u_expanded, diff_norm, dim=-1)
        alpha = (cross_prod * nei).sum(dim=2)
        phi = (u_expanded * diff_norm).sum(dim=2)
        theta = torch.atan2(
            (torch.cross(u_expanded, diff_norm, dim=-1) * nei).sum(dim=2),
            (u_expanded * diff_norm).sum(dim=2)
        )

        hist = torch.cat([
            torch.histc(alpha.view(-1), bins=self.num_bins, min=-1, max=1),
            torch.histc(phi.view(-1), bins=self.num_bins, min=-1, max=1),
            torch.histc(theta.view(-1), bins=self.num_bins, min=-np.pi, max=np.pi)
        ])
        return hist / hist.sum()

    def __call__(self, data):
        """
        计算点云数据的 FPFH。

        参数:
        data (torch_geometric.data.Data): 包含点云数据的对象。

        返回:
        torch_geometric.data.Data: 包含 FPFH 特征的更新后的数据对象。
        """
        pos = data.pos.to(self.device)
        idx = knn(pos, pos, k=self.k + 1)[1].view(-1, self.k + 1)[:, 1:]  # [N, k]

        fpfh_list = []
        for start in range(0, pos.size(0), self.chunk):
            end = min(start + self.chunk, pos.size(0))
            nei = pos[idx[start:end]] - pos[start:end].unsqueeze(1)  # [chunk, k, 3]

            # 逐点邻域法线（PCA 第一主方向）
            cov = torch.bmm(nei.transpose(1, 2), nei) / self.k  # [chunk, 3, 3]
            _, v = torch.linalg.eigh(cov.cpu())  # [chunk, 3]
            u = v[:, :, 0].to(self.device).unsqueeze(1)  # [chunk, 1, 3]

            # 扩展 u 的维度以匹配 diff_norm
            u_expanded = u.expand(-1, self.k, -1)  # [chunk, k, 3]

            # 计算角度
            diff_norm = nei / torch.norm(nei, dim=2, keepdim=True)
            alpha = (torch.cross(u_expanded, diff_norm, dim=-1) * nei).sum(dim=2)
            phi = (u_expanded * diff_norm).sum(dim=2)
            theta = torch.atan2(
                (torch.cross(u_expanded, diff_norm, dim=-1) * nei).sum(dim=2),
                (u_expanded * diff_norm).sum(dim=2)
            )

            # 逐点直方图并降维
            hist = torch.stack([
                torch.histc(alpha.view(-1), bins=self.num_bins, min=-1, max=1),
                torch.histc(phi.view(-1), bins=self.num_bins, min=-1, max=1),
                torch.histc(theta.view(-1), bins=self.num_bins, min=-np.pi, max=np.pi)
            ], dim=0).view(-1, 3 * self.num_bins)  # [chunk, 3*bins]

            fpfh_list.append(hist.cpu())

        # 🔽 关键点特征：形状 [161, 33]
        key_fpfh = torch.cat(fpfh_list, dim=0)  # [M, 3*bins]
        key_pos = pos[:key_fpfh.shape[0]]  # [M, 3]
        full_pos = data.pos.to(self.device)  # ✅ 搬到 CUDA

        # 🔽 KNN 插值回全点云
        assign_index = knn(key_pos, full_pos, 3)
        row, col = assign_index[0], assign_index[1]

        # ✅ 防止越界 + 搬设备
        row = row.clamp(0, key_fpfh.shape[0] - 1).to(self.device)
        col = col.clamp(0, full_pos.shape[0] - 1).to(self.device)

        # 距离加权
        dist = (full_pos[col] - key_pos[row]).norm(dim=1)
        weight = 1.0 / (dist + 1e-8)
        weight = weight / scatter_add(weight, col, dim_size=full_pos.shape[0])[col]

        # ✅ 全部 CUDA
        full_fpfh = torch.zeros(full_pos.shape[0], key_fpfh.shape[1], device=self.device)
        key_fpfh = key_fpfh.to(self.device)

        # ✅ 插值
        full_fpfh.index_add_(0, col, weight.unsqueeze(1) * key_fpfh[row])

        # 🔽 写回 data
        data.fpfh = full_fpfh  # [N, 33]


        return data

    def __repr__(self):
        return "{}(k={}, num_bins={})".format(self.__class__.__name__, self.k, self.num_bins)

class LocalBinaryPatterns:
    """
    零依赖多尺度 LBP：
      1. 现场算法线（PCA，k=25）
      2. 高度/法线均 4 值化（0-3）
      3. 输出 8 维直方图 [N,8]
    参数
    ----
    k        : 邻域点数
    use_height/use_normal : 开关
    """
    def __init__(self, k=16, use_height=True, use_normal=True):
        self.k          = k
        self.use_height = use_height
        self.use_normal = use_normal

    # ---------- 现场算法线 ----------
    def _compute_normal(self, pos):
        """输入 [N,3]，输出 [N,3] 单位法线"""
        idx = knn(pos, pos, k=self.k+1)[1].view(-1, self.k+1)[:, 1:]
        norm = torch.empty_like(pos)
        for start in range(0, pos.size(0), 4096):
            end  = min(start + 4096, pos.size(0))
            nei  = pos[idx[start:end]]                  # [B, k, 3]
            nei  = nei - nei.mean(dim=1, keepdim=True)  # 中心化
            cov  = torch.bmm(nei.transpose(1,2), nei) / self.k  # [B,3,3]
            # CPU 特征分解避 MAGMA
            eig, v = torch.linalg.eigh(cov.cpu())
            norm[start:end] = v[:, :, 0].to(pos.device)  # 最小特征值对应法线
        return norm

    # ---------- 4 值化 ----------
    def _quantize4(self, vals):
        """把连续值离散成 0-3 四档"""
        q = torch.quantile(vals, torch.tensor([0.25,0.5,0.75], device=vals.device))
        return torch.bucketize(vals, q)

    def __call__(self, data: Data):
        pos  = data.pos
        if self.use_normal:
            norm = self._compute_normal(pos)
        else:
            norm = None

        edge_idx = knn(pos, pos, k=self.k+1)[1].view(-1, self.k+1)[:, 1:]
        hist = torch.zeros(pos.size(0), 8, device=pos.device, dtype=torch.float32)

        for i in range(pos.size(0)):
            nei   = pos[edge_idx[i]]          # [k,3]
            bits  = []

            # 1. 高度 4 值
            if self.use_height:
                z_center = pos[i, 2]
                z_nei    = nei[:, 2]
                codes    = self._quantize4(z_nei - z_center)
                bits.extend(codes.tolist())

            # 2. 法线夹角 4 值
            if self.use_normal:
                n_center = norm[i]  # [3]
                n_nei = norm[edge_idx[i]]  # [k,3]
                cos = (n_nei * n_center).sum(dim=1).clamp(-1, 1)  # ← 修复
                ang = torch.acos(torch.abs(cos))
                codes = self._quantize4(ang)
                bits.extend(codes.tolist())

            # 3. 8 位直方图
            idx = torch.tensor(bits, device=pos.device, dtype=torch.long)
            hist[i] = torch.bincount(idx, minlength=8).float()

        data.lbp = hist

        return data

    def __repr__(self):
        return "{}(k={}, use_height={}, use_normal={})".format(
            self.__class__.__name__, self.k, self.use_height, self.use_normal
        )

class SHOTDescriptor(object):
    """Build the angular histogram and retain its first 32 channels."""

    def __init__(self, radius=1.0, num_bins=15, num_sectors=12, augment=False):
        self.radius      = radius
        self.num_bins    = num_bins
        self.num_sectors = num_sectors
        self.augment     = augment

    # ---------- 单塔核心（GPU only） ----------
    @autocast()                      # 自动混合精度加速
    def __call__(self, data):
        pos = data.pos
        if self.augment and self.training:        # 训练时随机旋转
            pos = self._random_rotate(pos)

        edge_index = radius(pos, pos, r=self.radius, max_num_neighbors=32)
        row, col   = edge_index[0], edge_index[1]

        rel = pos[col] - pos[row]                 # [E, 3]
        # 简易 PCA 法线（GPU）
        cov = torch.zeros(row.max()+1, 3, 3, device=pos.device)
        cov.index_add_(0, row, torch.bmm(rel.unsqueeze(2), rel.unsqueeze(1)))
        cov = cov / 32.0
        eig, v = torch.linalg.eigh(cov)           # 全程 CUDA
        u = v[:, :, 0]                            # 最小特征值方向

        # 局部坐标系
        u = u[row]
        ref = torch.tensor([1., 0, 0], device=pos.device).expand_as(u)
        v = F.normalize(torch.cross(u, ref), dim=1)
        w = torch.cross(u, v)

        # 投影
        x, y, z = (rel * v).sum(1), (rel * w).sum(1), (rel * u).sum(1)
        polar = torch.atan2(z, torch.norm(rel[:, :2], dim=1).clamp(min=1e-8))
        azim  = torch.atan2(y, x) + np.pi
        n_ang = torch.acos(torch.abs((u * rel).sum(1)).clamp(0, 1))

        # 直方图 bin（GPU）
        bin_polar = (polar / np.pi * self.num_bins).long().clamp(0, self.num_bins - 1)
        bin_azim  = (azim / (2 * np.pi) * self.num_sectors).long().clamp(0, self.num_sectors - 1)
        bin_norm  = (n_ang / np.pi * self.num_bins).long().clamp(0, self.num_bins - 1)

        idx_base = bin_azim * 2 * self.num_bins
        flat_idx = torch.cat([idx_base + bin_polar, idx_base + self.num_bins + bin_norm])
        counts   = torch.ones_like(flat_idx, dtype=torch.float32)
        shot_vec = torch.zeros(pos.size(0), 2 * self.num_bins * self.num_sectors, device=pos.device)
        # Accumulate each neighbour into its centre point and histogram bin.
        point_idx = torch.cat([row, row])
        shot_vec.index_put_((point_idx, flat_idx), counts, accumulate=True)
        shot = shot_vec / (counts.sum() + 1e-8)     # L1 归一化

        # GPU 内 z-score 标准化
        shot = (shot - shot.mean(0)) / (shot.std(0) + 1e-5)
        # 替换原来三行
        with torch.no_grad():
            shot = shot.to(pos.device)
            mean = shot.mean(0, keepdim=True)
            std = shot.std(0, keepdim=True) + 1e-5
            shot = torch.clamp((shot - mean) / std, -5, 5)  # 融合一次

        data.shot = shot[:, :32].contiguous()
        return data

    # ---------- 训练时随机 3 轴旋转（数据增强） ----------
    def _random_rotate(self, pos):
        theta = (torch.rand(3, device=pos.device) - 0.5) * 2 * np.pi / 18   # ±10°
        cx, sx = torch.cos(theta[0]), torch.sin(theta[0])
        cy, sy = torch.cos(theta[1]), torch.sin(theta[1])
        cz, sz = torch.cos(theta[2]), torch.sin(theta[2])
        Rx = torch.tensor([[1, 0, 0], [0, cx, -sx], [0, sx, cx]], device=pos.device)
        Ry = torch.tensor([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]], device=pos.device)
        Rz = torch.tensor([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]], device=pos.device)
        return pos @ Rz @ Ry @ Rx



    def __repr__(self):
        return (f"{self.__class__.__name__}("
                f"radius={self.radius}, "
                f"num_bins={self.num_bins}, num_sectors={self.num_sectors}, "
                f"output_dim=32)")


class MuFeatsCompute(object):
    """
    把用户指定的若干基础特征按顺序拼成一个大特征张量。
    支持：pos(=xyz)、lbp、shot、fpfh
    用法：
        mufeats = MuFeatsCompute(feats=['pos', 'lbp'])   # -> N×(3+8)=N×11
    """

    def __init__(self, feats: list, zscore: bool = True):
        assert len(feats) > 0, "至少要选一种特征"
        self.feats = feats
        self.zscore = zscore
        # ↓↓↓ 在这直接写死权重，想调就改这里 ↓↓↓
        self.weights = {
            'pos': 1.0,
            'fpfh': 0.5,
            'lbp': 0.5,
            'shot': 0.25,
            'ctsc': 0.25,
            'ct_geom': 0.5,
            'ct_height': 0.5,
            'ct_reliability': 0.5,
        }  # 缺失特征默认 1.0
        # ---------- 内部：全局 z-score ----------

    @staticmethod
    def _global_zscore(x: torch.Tensor) -> torch.Tensor:
        return (x - x.mean(0)) / (x.std(0).clamp_min(1e-6))

    def __call__(self, data: Data):
        cat_list = []
        for f in self.feats:
            if f == 'pos':
                tensor = data.pos[:, :3]                        # N×3
            elif f in [
                'lbp', 'shot', 'fpfh', 'ctsc',
                'ct_geom', 'ct_height', 'ct_reliability'
            ]:
                if not hasattr(data, f):
                    raise RuntimeError(f"data 没有提前计算好的属性 {f}")
                tensor = getattr(data, f)             # N×D
            else:
                raise ValueError(f"MuFeats 不支持的特征: {f}")
            # 固定跳过归一化的特征名单
            SKIP_NORM = {}  # 想禁止谁就写谁
            if self.zscore and f not in SKIP_NORM:  # ← 加了个 and 条件
                tensor = self._global_zscore(tensor)
            #加权
            tensor = tensor * self.weights.get(f, 1.0)
            cat_list.append(tensor.cpu())

        data.mufeats = torch.cat(cat_list, dim=1)
        return data

    def __repr__(self):
        return f"{self.__class__.__name__}(feats={self.feats})"

class TogFeatCompute(object):
    """
    把两个 **已算好** 的特征 A 和 B
    （默认 SHOT 和 FPFH，可改）
    先各自可选地做 PCA→3 维，再逐点相加，得到 N×3 新特征 togfeatures，
    最后像 lbp/shot/fpfh 一样通过 AddFeatsByKeys 拼进 data.x
    """

    def __init__(self,
                 feat1_key: str = "shot",
                 feat2_key: str = "fpfh",
                 pca1: bool = False,  # ← 默认 False
                 pca2: bool = False,  # ← 默认 False
                 out_key: str = "togfeats",
                 zscore: bool = True):
        self.feat1_key = feat1_key
        self.feat2_key = feat2_key
        self.pca1 = pca1
        self.pca2 = pca2
        self.out_key = out_key
        self.zscore = zscore

        # ---------- 内部：全局 z-score ----------

    @staticmethod
    def _global_zscore(x: torch.Tensor) -> torch.Tensor:
        return (x - x.mean(0)) / (x.std(0).clamp_min(1e-6))

    # ---------- 内部：GPU PCA → 3 维 ----------
    @staticmethod
    @torch.cuda.amp.autocast(enabled=False)
    def _pca_to_3d(x: torch.Tensor) -> torch.Tensor:
        x = x.float()
        x_c = x - x.mean(0, keepdim=True)
        cov = x_c.T.mm(x_c) / (x_c.size(0) - 1)
        _, v = torch.linalg.eigh(cov)          # 升序
        return x_c.mm(v[:, :3])                # [N,3]

    def __call__(self, data: Data) -> Data:
        f1 = getattr(data, self.feat1_key, None)
        f2 = getattr(data, self.feat2_key, None)
        if f1 is None or f2 is None:
            raise RuntimeError(f"[togfeats] 缺少 {self.feat1_key} 或 {self.feat2_key}")
        if self.zscore:  # ← 各自 z-score
            f1 = self._global_zscore(f1)
            f2 = self._global_zscore(f2)
        if self.pca1:
            f1 = self._pca_to_3d(f1)
        if self.pca2:
            f2 = self._pca_to_3d(f2)
        if f1.shape[0] != f2.shape[0]:
            raise RuntimeError("[togfeats] 点数不一致")
        setattr(data, self.out_key, f1 + f2)
        return data

    def __repr__(self):
        return (f"{self.__class__.__name__}("
                f"{self.feat1_key}+pca{self.pca1} + "
                f"{self.feat2_key}+pca{self.pca2} → {self.out_key})")
