import random
import torch

# Those Transformation are adapted from https://github.com/chrischoy/SpatioTemporalSegmentation/blob/master/lib/transforms.py


class DropFeature:
    """ Sets the given feature to 0 with a given probability

    Parameters
    ----------
    drop_proba:
        Probability that the feature gets dropped
    feature_name:
        Name of the feature to drop
    """

    def __init__(self, drop_proba=0.2, feature_name=None):
        if feature_name is None:
            raise ValueError("DropFeature requires an explicit feature_name")
        self._drop_proba = drop_proba
        self._feature_name = feature_name

    def __call__(self, data):
        assert hasattr(data, self._feature_name)
        if random.random() < self._drop_proba:
            data[self._feature_name] = data[self._feature_name] * 0
        return data

    def __repr__(self):
        return "DropFeature: proba = {}, feature = {}".format(self._drop_proba, self._feature_name)


class Jitter:
    """
    add a small gaussian noise to the feature.
    Parameters
    ----------
    mu: float
        mean of the gaussian noise
    sigma: float
        standard deviation of the gaussian noise
    p: float
        probability of noise
    """

    def __init__(self, mu=0, sigma=0.01, p=0.95):
        self.mu = mu
        self.sigma = sigma
        self.p = p

    def __call__(self, data):
        if random.random() < self.p:
            data.x += torch.randn_like(data.x) * self.sigma + self.mu
        return data

    def __repr__(self):
        return "Jitter(mu={}, sigma={})".format(self.mu, self.sigma)
