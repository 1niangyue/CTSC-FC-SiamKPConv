import collections
import errno
import numpy as np
import os
import os.path as osp
import torch
from torch_geometric.data import Data
from torch_points_kernels.points_cpu import ball_query

from torch_points3d.core.data_transform import GridSampling3D, SaveOriginalPosId
from torch_geometric.transforms import Compose
from torch_cluster import fps


def to_list(x):
    """
    taken from https://pytorch-geometric.readthedocs.io/en/latest/_modules/torch_geometric/data/dataset.html#Dataset
    """
    if not isinstance(x, collections.Iterable) or isinstance(x, str):
        x = [x]
    return x


def files_exist(files):
    """
    taken from https://pytorch-geometric.readthedocs.io/en/latest/_modules/torch_geometric/data/dataset.html#Dataset
    """

    return all([osp.exists(f) for f in files])


def makedirs(path):
    """
    taken from https://github.com/rusty1s/pytorch_geometric/blob/master/torch_geometric/data/makedirs.py
    """
    try:
        os.makedirs(osp.expanduser(osp.normpath(path)))
    except OSError as e:
        if e.errno != errno.EEXIST and osp.isdir(path):
            raise e


def get_urls(filename):
    res = []
    with open(filename, "r") as f:
        res = f.readlines()
    return res


def extract_pcd(depth_image, K):
    """
    transform a depth image into a pointcloud (here a numpy array)
    """

    Z = (depth_image / 1000).ravel()
    mask_z = (Z < 6) * (Z > 0)
    X, Y = np.meshgrid(np.arange(depth_image.shape[1]), np.arange(depth_image.shape[0]))

    Xworld = (X.ravel()[mask_z] + 0.5 - K[0, 2]) * Z[mask_z] / K[0, 0]
    Yworld = (Y.ravel()[mask_z] + 0.5 - K[1, 2]) * Z[mask_z] / K[1, 1]

    pcd = np.vstack((Xworld, Yworld, Z[mask_z])).T
    return pcd




    # concatenate all fragment

    # create batches
    # save fragments for each batches using a simple batch


def filter_pair(pair, dist):
    """
    give a pair of indices where the distance is positive
    """
    pair = pair[dist[:, 0] >= 0]
    if len(pair) > 0:
        pair = pair.numpy()[:, ::-1]
    else:
        pair = np.array([])
    return pair


def compute_overlap_and_matches(data1, data2, max_distance_overlap, reciprocity=False, num_pos=1, trans_gt=torch.eye(4)):

    # we can use ball query on cpu because the points are sorted
    # print(len(data1.pos), len(data2.pos), max_distance_overlap)
    pair, dist = ball_query(
        data2.pos.to(torch.float),
        data1.pos.to(torch.float) @ trans_gt[:3, :3].T + trans_gt[:3, 3],
        radius=max_distance_overlap,
        max_num=num_pos, mode=1, sorted=True)
    pair = filter_pair(pair, dist)
    pair2 = []
    overlap = [pair.shape[0] / len(data1.pos)]
    if reciprocity:
        pair2, dist2 = ball_query(
            data1.pos.to(torch.float) @ trans_gt[:3, :3].T + trans_gt[:3, 3],
            data2.pos.to(torch.float),
            radius=max_distance_overlap,
            max_num=num_pos, mode=1, sorted=True)
        pair2 = filter_pair(pair2, dist2)
        overlap.append(pair2.shape[0] / len(data2.pos))
    # overlap = pair.shape[0] / \
    #    (len(data1.pos) + len(data2.pos) - pair.shape[0])
    # print(pair)

    # print(path1, path2, "overlap=", overlap)
    output = dict(pair=pair, pair2=pair2, overlap=overlap)
    return output

def compute_subsampled_matches(data1, data2, voxel_size=0.1, max_distance_overlap=0.02):
    """
    compute matches on subsampled version of data and track ind
    """
    grid_sampling = Compose([SaveOriginalPosId(), GridSampling3D(voxel_size, mode='last')])
    subsampled_data = grid_sampling(data1.clone())
    origin_id = subsampled_data.origin_id.numpy()
    pair = compute_overlap_and_matches(subsampled_data, data2, max_distance_overlap)['pair']
    pair[:, 0] = origin_id[pair[:, 0]]
    return torch.from_numpy(pair.copy())





class PatchExtractor:
    r"""
    Extract patches on a point cloud
    """

    def __init__(self, radius_patch):
        self.radius_patch = radius_patch

    def __call__(self, data: Data, ind):

        pos = data.pos
        point = pos[ind].view(1, 3)
        ind, dist = ball_query(point, pos, radius=self.radius_patch, max_num=-1, mode=1)

        row, col = ind[dist[:, 0] > 0].t()
        patch = Data()
        for key in data.keys:
            if torch.is_tensor(data[key]):
                if torch.all(col < data[key].shape[0]):
                    patch[key] = data[key][col]

        return patch


def tracked_matches(data_s, data_t, pair):
    """
    allow to keep the index that are still present after a sparse input
    Parameters:
    pair : P x 2 indices of the matched points before any transformation
    """

    pair_np = pair.numpy()
    mask_s = np.isin(pair_np[:, 0], data_s.origin_id.numpy())
    mask_t = np.isin(pair_np[:, 1], data_t.origin_id.numpy())
    # print(data_s.origin_id.shape)
    # print(data_s.pos.shape)
    # print(data_s.xyz.shape)
    mask = np.logical_and(mask_s, mask_t)
    filtered_pair = pair_np[mask]

    table_s = dict(zip(data_s.origin_id.numpy(),
                       np.arange(0, len(data_s.pos))))
    table_t = dict(zip(data_t.origin_id.numpy(),
                       np.arange(0, len(data_t.pos))))
    res = torch.tensor([[table_s[p[0]], table_t[p[1]]] for p in filtered_pair]).to(torch.long)
    return res



def fps_sampling(pair_ind, pos, num_pos_pairs, ind=0):
    """
    perform fps sampling to choose the positive pairs
    Parameters:
        pair_ind: torch tensor which represents index of pair size N x 2
        pos: torch tensor which represents the point cloud of size M x 3
        num_pos_pairs: int which number of pairs we want()
        ind: must be 0 or 1
    """
    small_pos_source = pos[pair_ind[:, ind]]
    batch = torch.zeros(small_pos_source.shape[0]).long()
    ratio = float(num_pos_pairs) / len(pair_ind)
    if(ratio <= 0 or ratio >= 1):
        raise ValueError("ratio cannot have this value: {}".format(ratio))
    index = fps(small_pos_source, batch, ratio=ratio, random_start=False)
    return index
