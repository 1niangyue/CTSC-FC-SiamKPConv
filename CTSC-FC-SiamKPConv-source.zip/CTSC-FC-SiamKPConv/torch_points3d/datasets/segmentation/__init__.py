IGNORE_LABEL: int = -1

from .shapenet import ShapeNet, ShapeNetDataset
