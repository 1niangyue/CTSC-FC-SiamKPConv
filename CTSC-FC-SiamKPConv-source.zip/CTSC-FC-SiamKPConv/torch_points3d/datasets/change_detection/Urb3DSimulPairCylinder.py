import warnings
import os
import os.path as osp
from itertools import repeat, product
import numpy as np
import h5py
import torch
import random
import glob
import csv
from plyfile import PlyData, PlyElement
from torch_geometric.data import Data, extract_zip, Dataset
from torch_geometric.data.dataset import files_exist
from torch_geometric.data import DataLoader
import torch_geometric.transforms as T
import logging
from sklearn.neighbors import NearestNeighbors, KDTree
from tqdm.auto import tqdm as tq
import csv
import pandas as pd
import pickle
import gdown
import shutil

from torch_points3d.core.data_transform import GridSampling3D, CylinderSampling, SphereSampling
from torch_points3d.datasets.change_detection.base_siamese_dataset import BaseSiameseDataset
from torch_points3d.datasets.change_detection.pair import Pair, MultiScalePair
from torch_points3d.metrics.urb3DCD_tracker import Urb3DCDTracker

from matplotlib import cm
from torch_points3d.core.data_transform.features import FPFHCompute, SHOTDescriptor, LocalBinaryPatterns,PCACompute, AddFeatsByKeys,MuFeatsCompute,TogFeatCompute,XYZFeature,CrossTemporalFeatures
from torch_geometric.transforms import Compose

IGNORE_LABEL: int = -1

URB3DCD_NUM_CLASSES = 7
viridis = cm.get_cmap('viridis', URB3DCD_NUM_CLASSES)

INV_OBJECT_LABEL = {
    0: "unchanged",
    1: "newlyBuilt",
    2: "deconstructed",
    3: "newVegetation",
    4: "vegetationGrowUp",
    5: "vegetationRemoved",
    6: "mobileObjects"
}

# INV_OBJECT_LABEL = {i:"class " + str(i) for i in range(URB3DSIMUL_NUM_CLASSES)}
#V1
# OBJECT_COLOR = np.asarray(
#     [
#         [67, 1, 84],  # 'unchanged'
#         [0, 150, 128],  # 'newlyBuilt'
#         [255, 208, 0],  # 'deconstructed'
#
#     ]
# )

#V2
OBJECT_COLOR = np.asarray(
    [
        [67, 1, 84],  # 'unchanged'
        [0, 183, 255],  # 'newlyBuilt'
        [0, 12, 235],  # 'deconstructed'
        [0, 217, 33],  # 'newVegetation'
        [255, 230, 0],  # 'vegetationGrowUp'
        [255, 140, 0],  # 'vegetationRemoved'
        [255, 0, 0],  # 'mobileObjects'
    ]
)
OBJECT_LABEL = {name: i for i, name in INV_OBJECT_LABEL.items()}

class Urb3DSimul(Dataset):
    """
    Definition of Urb3DCD Dataset
    """

    def __init__(self, sample_per_epoch=6000, filePaths="", split="train", DA=True, pre_transform=None, transform=None,
                 preprocessed_dir="",reload_preproc= True, reload_trees=True, nameInPly="params", comp_norm=True,
                 feat_names: list = None, mufeats_comps: list = None):
        self.comp_norm = comp_norm
        self.feat_names = feat_names or []
        self.mufeats_comps = mufeats_comps or []
        self._feat_transform = self._build_feat_transform()
        super(Urb3DSimul, self).__init__(None, None, pre_transform)
        self.class_labels = OBJECT_LABEL
        self._ignore_label = IGNORE_LABEL
        self.preprocessed_dir = preprocessed_dir
        if not osp.isdir(self.preprocessed_dir):
            os.makedirs(self.preprocessed_dir)
        self.filePaths = filePaths
        self.nameInPly = nameInPly
        self._get_paths()
        self.split = split
        self.DA = DA
        self.pre_transform = pre_transform
        self.transform = None
        self.manual_transform = transform
        self.reload_preproc = reload_preproc
        self.reload_trees = reload_trees
        self.num_classes = URB3DCD_NUM_CLASSES
        self.nb_elt_class = torch.zeros(self.num_classes)
        self.filesPC0_prepoc = [None] * len(self.filesPC0)
        self.filesPC1_prepoc = [None] * len(self.filesPC1)
        self.sample_per_epoch = sample_per_epoch

        self.process_files = []

        AVAILABLE_SPLITS = ["Train", "Val", "Test"]

        self.process(comp_normal=comp_norm)
        if self.nb_elt_class.sum() == 0:
            self.get_nb_elt_class()
        self.weight_classes = 1 - self.nb_elt_class / self.nb_elt_class.sum()

    def _build_feat_transform(self):
        transforms = []
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        cross_temporal_names = {"ctsc", "ct_geom", "ct_height", "ct_reliability"}

        for name in self.feat_names:
            if name == "pos":
                # data.pos already exists.  Keeping "pos" in feat_names makes
                # it available both for direct concatenation and for mufeats.
                continue
            elif name in cross_temporal_names:
                # These descriptors require both epochs and are computed together
                # in hand_craft_process after all single-cloud descriptors.
                continue
            elif name == "pos_f":
                # 把原始坐标当成 3 维特征注入
                transforms.append(XYZFeature())
            elif name == "fpfh":
                transforms.append(FPFHCompute(k=25, num_bins=15, device=device))
            elif name == "shot":
                transforms.append(SHOTDescriptor(radius=1.0, num_bins=15, num_sectors=12))
            elif name == "lbp":
                transforms.append(LocalBinaryPatterns(k=16, use_height=True, use_normal=True))
            elif name == "eigenvalues":
                transforms.append(PCACompute())  # 会生成 eigenvalues/eigenvectors
            elif name == "mufeats":
                # Delayed until after cross-temporal descriptors have been
                # computed, so combinations such as pos+ctsc are valid.
                continue
            elif name == "togfeats":
                idx = self.feat_names.index("togfeats")
                if idx < 2:  # 前两个就是 togfeats → 跳过
                    warnings.warn("[togfeats] 排在 feat_names 前两位，已自动跳过计算")
                    continue

                # 自动取前面相邻的两个特征
                feat1_key = self.feat_names[idx - 2]
                feat2_key = self.feat_names[idx - 1]

                transforms.append(TogFeatCompute(feat1_key=feat1_key,feat2_key=feat2_key,pca1=False,pca2=False))
            else:
                raise ValueError(f"Unknown feature: {name}")

        return Compose(transforms) if transforms else None

    def _append_selected_features(self, data):
        """Concatenate descriptors in YAML order after pair features exist."""
        if not self.feat_names:
            return data
        trigger = next((n for n in self.feat_names if n in {"mufeats", "togfeats"}), None)
        add_names = [trigger] if trigger else self.feat_names
        return AddFeatsByKeys(
            list_add_to_x=[True] * len(add_names),
            feat_names=add_names,
            input_nc_feats=None,
            stricts=[True] * len(add_names),
        )(data)

    @property
    def raw_file_names(self):
        return ["URBAN3DCD"]

    @property
    def processed_file_names(self):
        return [s for s in self.AVAILABLE_SPLITS[:-1]]

    def _get_paths(self):
        self.filesPC0 = []
        self.filesPC1 = []
        globPath = os.scandir(self.filePaths)
        for dir in globPath:
            if dir.is_dir():
                curDir = os.scandir(dir)
                for f in curDir:
                    if f.name == "pointCloud0.ply":
                        self.filesPC0.append(f.path)
                    elif f.name == "pointCloud1.ply":
                        self.filesPC1.append(f.path)
                curDir.close()
        globPath.close()

    def size(self):
        return len(self.filesPC0)

    def len(self):
        if self.sample_per_epoch > 0:
            return self.sample_per_epoch

    # def len(self):
    #     return len(self.process_files)

    def get_nb_elt_class(self):
        self.nb_elt_class = torch.zeros(self.num_classes)
        for idx in range(len(self.filesPC0)):
            pc1 = torch.load(osp.join(self.preprocessed_dir, 'pc1_{}.pt'.format(idx)))
            cpt = torch.bincount(pc1.y)
            for c in range(cpt.shape[0]):
                self.nb_elt_class[c] += cpt[c]

    def hand_craft_process(self, comp_normal):

        exist_file = True
        for idx in range(len(self.filesPC0)):
            exist_file &= osp.isfile(osp.join(self.preprocessed_dir, f'pc0_{idx}.pt'))
            exist_file &= osp.isfile(osp.join(self.preprocessed_dir, f'pc1_{idx}.pt'))

        if not self.reload_preproc or not exist_file:
            for idx in tq(range(len(self.filesPC0)), desc="Compute feats"):
                if idx == 0:  # 只打印第 1 个样本，防止刷屏
                    print(f"[Dataset] 第 1 个样本  feat_names={self.feat_names}")

                # 1. 加载原始点云
                pos0,pos1,label= self.clouds_loader(idx, nameInPly=self.nameInPly)

                # 2. 构造 Data
                data_pc0 = Data(pos=pos0)
                data_pc1 = Data(pos=pos1, y=label)

                # 3. 计算特征（自动拼到 data.x）
                if self._feat_transform:
                    data_pc0 = self._feat_transform(data_pc0)
                    data_pc1 = self._feat_transform(data_pc1)

                cross_names = [n for n in self.feat_names if n in
                               {"ctsc", "ct_geom", "ct_height", "ct_reliability"}]
                if cross_names:
                    data_pc0, data_pc1 = CrossTemporalFeatures()(data_pc0, data_pc1)

                if "mufeats" in self.feat_names:
                    if not self.mufeats_comps:
                        raise ValueError(
                            "feat_names contains 'mufeats' but mufeats_comps is empty"
                        )
                    comp_list = [x.strip() for x in self.mufeats_comps.split('+') if x.strip()]
                    mu_transform = MuFeatsCompute(comp_list)
                    data_pc0 = mu_transform(data_pc0)
                    data_pc1 = mu_transform(data_pc1)

                data_pc0 = self._append_selected_features(data_pc0)
                data_pc1 = self._append_selected_features(data_pc1)

                # 4. 统计类别权重
                cpt = torch.bincount(data_pc1.y)
                for c in range(cpt.shape[0]):
                    self.nb_elt_class[c] += cpt[c]

                # 5. 缓存

                torch.save(data_pc0.cpu(), osp.join(self.preprocessed_dir, f'pc0_{idx}.pt'))
                torch.save(data_pc1.cpu(), osp.join(self.preprocessed_dir, f'pc1_{idx}.pt'))
                self.process_files.append(osp.join(self.preprocessed_dir, 'pc0_{}.pt'.format(idx)))

    def process(self, comp_normal = False):
        self.hand_craft_process(comp_normal)

    def get(self, idx):
        if self.pre_transform is not None:
            pc0, pc1, label = self._preproc_clouds_loader(idx)
        else:
            pc0, pc1, label = self.clouds_loader(idx, nameInPly=self.nameInPly)
        if (hasattr(pc0, "multiscale")):
            batch = MultiScalePair(pos=pc0, pos_target=pc1, y=label)
        else:
            batch = Pair(pos=pc0, pos_target=pc1, y=label)
            batch.normalise()
        return batch.contiguous()

    def clouds_loader(self, area, nameInPly = "params"):
        print("Loading " + self.filesPC1[area])
        pc = self.cloud_loader(self.filesPC1[area], nameInPly=nameInPly)
        pc1 = pc[:, :3]
        gt = pc[:, 3].long() #/!\ Labels should be at the 4th column 0:X 1:Y 2:Z 3:LAbel
        pc0 = self.cloud_loader(self.filesPC0[area], nameInPly=nameInPly)
        pc0 = pc0[:, :3]
        return pc0.type(torch.float), pc1.type(torch.float), gt

    def _preproc_clouds_loader(self, area):
        data_pc0 = torch.load(osp.join(self.preprocessed_dir, 'pc0_{}.pt'.format(area)), map_location='cpu')
        data_pc1 = torch.load(osp.join(self.preprocessed_dir, 'pc1_{}.pt'.format(area)), map_location='cpu')
        return data_pc0.pos, data_pc1.pos, data_pc1.y, data_pc0.x, data_pc1.x

    def read_from_ply(self,filename, nameInPly="params", name_feat="label_ch"):
        """read XYZ for each vertex."""
        assert os.path.isfile(filename)
        with open(filename, "rb") as f:
            plydata = PlyData.read(f)
            num_verts = plydata[nameInPly].count
            vertices = np.zeros(shape=[num_verts, 4], dtype=np.float32)
            vertices[:, 0] = plydata[nameInPly].data["x"]
            vertices[:, 1] = plydata[nameInPly].data["y"]
            vertices[:, 2] = plydata[nameInPly].data["z"]
            vertices[:, 3] = plydata[nameInPly].data[name_feat]

        return vertices

    def cloud_loader(self, pathPC, cuda=False, nameInPly=None, name_feat = "label_ch"):
        """
      load a tile and returns points features (normalized xyz + intensity) and
      ground truth
      INPUT:
      pathPC = string, path to the tile of PC
      OUTPUT
      pc_data, [n x 3] float array containing points coordinates and intensity
      lbs, [n] long int array, containing the points semantic labels
      """
        if nameInPly is None:
            pc_data = self.read_from_ply(pathPC, nameInPly="params", name_feat=name_feat)
        else:
            pc_data = self.read_from_ply(pathPC, nameInPly=nameInPly, name_feat=name_feat)
        # load the point cloud data
        pc_data = torch.from_numpy(pc_data)

        if cuda:  # put the cloud data on the GPU memory
            pc_data = pc_data.cuda()
        return pc_data

    @property
    def num_features(self):
        feature_dims = {
            "pos": 3,
            "pos_f": 1,
            "fpfh": 45,
            "shot": 32,
            "lbp": 8,
            "eigenvalues": 3,
            "togfeats": 3,
            "ctsc": 10,
            "ct_geom": 4,
            "ct_height": 3,
            "ct_reliability": 3,
        }

        # When mufeats is selected, _append_selected_features deliberately
        # sends only the combined tensor to the network.  Dependencies listed
        # in feat_names must therefore not be counted a second time.
        if "mufeats" in self.feat_names:
            if not self.mufeats_comps:
                return 0
            comps = [x.strip() for x in self.mufeats_comps.split('+') if x.strip()]
            unknown = [name for name in comps if name not in feature_dims]
            if unknown:
                raise ValueError("Unsupported mufeats components: {}".format(unknown))
            return sum(feature_dims[name] for name in comps)

        base = 0
        for name in self.feat_names:
            if name in feature_dims:
                base += feature_dims[name]
        return base

class Urb3DSimulSphere(Urb3DSimul):
    """ Small variation of Urb3DCD that allows random sampling of spheres
    within an Area during training and validation. Spheres have a radius of 2m. If sample_per_epoch is not specified, spheres
    are taken on a 2m grid.

    http://buildingparser.stanford.edu/dataset.html

    Parameters
    ----------
    root: str
        path to the directory where the data will be saved
    test_area: int
        number between 1 and 6 that denotes the area used for testing
    train: bool
        Is this a train split or not
    pre_collate_transform:
        Transforms to be applied before the data is assembled into samples (apply fusing here for example)
    keep_instance: bool
        set to True if you wish to keep instance data
    sample_per_epoch
        Number of spheres that are randomly sampled at each epoch (-1 for fixed grid)
    radius
        radius of each sphere
    pre_transform
    transform
    pre_filter
    """

    def __init__(self, sample_per_epoch=100, radius=2, fix_cyl=False, *args, **kwargs):
        self._sample_per_epoch = sample_per_epoch
        self._radius = radius
        self._grid_sphere_sampling = GridSampling3D(size=radius / 10.0)
        self.fix_cyl = fix_cyl
        super().__init__(*args, **kwargs)
        self._prepare_centers()
        # Trees are built in case it needs, now don't need to compute anymore trees
        self.reload_trees = True

    def __len__(self):
        if self._sample_per_epoch > 0:
            return self._sample_per_epoch
        else:
            return self.grid_regular_centers.shape[0]

    def get(self, idx, dc = False):
        if self._sample_per_epoch > 0:
            if self.fix_cyl:
                centre = self._centres_for_sampling_fixed[idx, :3]
                area_sel = self._centres_for_sampling_fixed[idx, 3].int()
                pair = self._load_save(area_sel)
                sphere_sampler = SphereSampling(self._radius, centre, align_origin=False)
                dataPC0 = Data(pos=pair.pos)
                setattr(dataPC0, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
                dataPC1 = Data(pos=pair.pos_target, y=pair.y)
                setattr(dataPC1, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
                dataPC0_sphere = sphere_sampler(dataPC0)
                dataPC1_sphere = sphere_sampler(dataPC1)
                pair_spheres = Pair(pos=dataPC0_sphere.pos, pos_target=dataPC1_sphere.pos, y=dataPC1_sphere.y)
                pair_spheres.normalise()
                return pair_spheres
            else:
                return self._get_random()
        else:
            centre = self.grid_regular_centers[idx, :3]
            area_sel = self.grid_regular_centers[idx, 3].int()
            pair = self._load_save(area_sel)
            sphere_sampler = SphereSampling(self._radius, centre, align_origin=False)
            dataPC0 = Data(pos=pair.pos)
            setattr(dataPC0, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
            dataPC1 = Data(pos=pair.pos_target, y=pair.y)
            setattr(dataPC1, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
            dataPC0_sphere = sphere_sampler(dataPC0)
            dataPC1_sphere = sphere_sampler(dataPC1)
            if self.manual_transform is not None:
                dataPC0_sphere = self.manual_transform(dataPC0_sphere)
                dataPC1_sphere = self.manual_transform(dataPC1_sphere)
            pair_spheres = Pair(pos=dataPC0_sphere.pos, pos_target=dataPC1_sphere.pos, y=dataPC1_sphere.y)
            pair_spheres.normalise()
            return pair_spheres.contiguous()


    def _get_random(self):
        # Random spheres biased towards getting more low frequency classes
        chosen_label = np.random.choice(self._labels, p=self._label_counts)
        valid_centres = self._centres_for_sampling[self._centres_for_sampling[:, 4] == chosen_label]
        centre_idx = int(random.random() * (valid_centres.shape[0] - 1))
        centre = valid_centres[centre_idx]
        #  choice of the corresponding PC if several PCs are loaded
        area_sel = centre[3].int()
        pair = self._load_save(area_sel)
        sphere_sampler = SphereSampling(self._radius, centre[:3], align_origin=False)
        dataPC0 = Data(pos=pair.pos)
        setattr(dataPC0, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
        dataPC1 = Data(pos=pair.pos_target, y=pair.y)
        setattr(dataPC1, SphereSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
        dataPC0_sphere = sphere_sampler(dataPC0)
        dataPC1_sphere = sphere_sampler(dataPC1)
        if self.manual_transform is not None:
            dataPC0_sphere = self.manual_transform(dataPC0_sphere)
            dataPC1_sphere = self.manual_transform(dataPC1_sphere)
        pair_sphere = Pair(pos=dataPC0_sphere.pos, pos_target=dataPC1_sphere.pos, y=dataPC1_sphere.y)
        pair_sphere.normalise()
        return pair_sphere

    def _prepare_centers(self):
        self._centres_for_sampling = []
        grid_sampling = GridSampling3D(size=self._radius / 2)
        self.grid_regular_centers = []
        for i in range(len(self.filesPC0)):
            pair = self._load_save(i)
            if self._sample_per_epoch > 0:
                dataPC1 = Data(pos=pair.pos_target, y=pair.y)
                low_res = self._grid_sphere_sampling(dataPC1)
                centres = torch.empty((low_res.pos.shape[0], 5), dtype=torch.float)
                centres[:, :3] = low_res.pos
                centres[:, 3] = i
                centres[:, 4] = low_res.y
                self._centres_for_sampling.append(centres)
            else:
                # Get regular center on PC1, PC0 will be sampled using the same center
                dataPC1 = Data(pos=pair.pos_target, y=pair.y)
                grid_sample_centers = grid_sampling(dataPC1.clone())
                centres = torch.empty((grid_sample_centers.pos.shape[0], 4), dtype=torch.float)
                centres[:, :3] = grid_sample_centers.pos
                centres[:, 3] = i
                self.grid_regular_centers.append(centres)

        if self._sample_per_epoch > 0:
            self._centres_for_sampling = torch.cat(self._centres_for_sampling, 0)
            uni, uni_counts = np.unique(np.asarray(self._centres_for_sampling[:, -1]), return_counts=True)
            print(uni_counts)
            uni_counts = np.sqrt(uni_counts.mean() / uni_counts)
            self._label_counts = uni_counts / np.sum(uni_counts)
            print(self._label_counts)
            self._labels = uni
            self.weight_classes = torch.from_numpy(self._label_counts).type(torch.float)
            if self.fix_cyl:
                self._centres_for_sampling_fixed = []
                # choice of cylinders for all the training
                np.random.seed(1)
                chosen_labels = np.random.choice(self._labels, p=self._label_counts, size=(self._sample_per_epoch, 1))
                uni, uni_counts = np.unique(chosen_labels, return_counts=True)
                print("fixed cylinder", uni, uni_counts)
                for c in range(uni.shape[0]):
                    valid_centres = self._centres_for_sampling[self._centres_for_sampling[:, -1] == uni[c]]
                    centres_idx = np.random.randint(low = 0, high=valid_centres.shape[0], size=(uni_counts[c],1))
                    self._centres_for_sampling_fixed.append(np.squeeze(valid_centres[centres_idx,:], axis=1))
                self._centres_for_sampling_fixed = torch.cat(self._centres_for_sampling_fixed, 0)
        else:
            self.grid_regular_centers = torch.cat(self.grid_regular_centers, 0)

    def _load_save(self, i):
        if self.pre_transform is not None:
            pc0, pc1, label = self._preproc_clouds_loader(i)
        else:
            pc0, pc1, label = self.clouds_loader(i, nameInPly=self.nameInPly)
        pair = Pair(pos=pc0, pos_target=pc1, y=label)
        path = self.filesPC0[i]
        name_tree = os.path.basename(path).split(".")[0] + "_radius" + str(int(self._radius)) + "_" + str(i) + ".p"
        path_treesPC0 = os.path.join(self.preprocessed_dir, "tp3DTree", name_tree)  # osp.dirname(path)
        if self.reload_trees and osp.isfile(path_treesPC0):
            file = open(path_treesPC0, "rb")
            tree = pickle.load(file)
            file.close()
            pair.KDTREE_KEY_PC0 = tree
        else:
            # tree not existing yet should be saved
            # test if tp3D directory exists
            if not osp.isdir(os.path.join(self.preprocessed_dir, "tp3DTree")):
                os.makedirs(osp.join(self.preprocessed_dir, "tp3DTree"))
            tree = KDTree(np.asarray(pc0), leaf_size=10)
            file = open(path_treesPC0, "wb")
            pickle.dump(tree, file)
            file.close()
            pair.KDTREE_KEY_PC0 = tree

        path = self.filesPC1[i]
        name_tree = os.path.basename(path).split(".")[0] + "_radius" + str(int(self._radius)) + "_" + str(i) + ".p"
        path_treesPC1 = os.path.join(self.preprocessed_dir, "tp3DTree", name_tree)
        if self.reload_trees and osp.isfile(path_treesPC1):
            file = open(path_treesPC1, "rb")
            tree = pickle.load(file)
            file.close()
            pair.KDTREE_KEY_PC1 = tree
        else:
            # tree not existing yet should be saved
            # test if tp3D directory exists
            if not os.path.isdir(os.path.join(self.preprocessed_dir, "tp3DTree")):
                os.makedirs(os.path.join(self.preprocessed_dir, "tp3DTree"))
            tree = KDTree(np.asarray(pc1), leaf_size=10)
            file = open(path_treesPC1, "wb")
            pickle.dump(tree, file)
            file.close()
            pair.KDTREE_KEY_PC1 = tree
        return pair


class Urb3DSimulCylinder(Urb3DSimulSphere):
    def get(self, idx):
        if self._sample_per_epoch > 0:
            if self.fix_cyl:
                pair_correct = False
                while not pair_correct and idx < self._centres_for_sampling_fixed.shape[0]:
                    centre = self._centres_for_sampling_fixed[idx, :3]
                    area_sel = self._centres_for_sampling_fixed[idx, 3].int()  # ---> ici choix du pc correspondant si pls pc chargés
                    pair = self._load_save(area_sel)
                    cylinder_sampler = CylinderSampling(self._radius, centre, align_origin=False)
                    dataPC0 = Data(pos=pair.pos, idx=torch.arange(pair.pos.shape[0]).reshape(-1))
                    setattr(dataPC0, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
                    dataPC1 = Data(pos=pair.pos_target, y=pair.y, idx=torch.arange(pair.pos_target.shape[0]).reshape(-1))
                    setattr(dataPC1, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
                    dataPC0_cyl = cylinder_sampler(dataPC0)
                    dataPC1_cyl = cylinder_sampler(dataPC1)
                    pair_cylinders = Pair(pos=dataPC0_cyl.pos, pos_target=dataPC1_cyl.pos, y=dataPC1_cyl.y,
                                          idx=dataPC0_cyl.idx, idx_target=dataPC1_cyl.idx, area=area_sel)
                    try:
                        pair_cylinders.normalise()
                        pair_correct = True
                    except:
                        print(pair_cylinders.pos.shape)
                        print(pair_cylinders.pos_target.shape)
                        idx += 1
                return pair_cylinders
            else:
                return self._get_random()
        else:
            pair_correct = False
            while not pair_correct and idx<self.grid_regular_centers.shape[0]:
                centre = self.grid_regular_centers[idx, :3]
                area_sel = self.grid_regular_centers[idx, 3].int()
                pair = self._load_save(area_sel)
                cylinder_sampler = CylinderSampling(self._radius, centre, align_origin=False)
                dataPC0 = Data(pos=pair.pos, x=pair.x,idx=torch.arange(pair.pos.shape[0]).reshape(-1))
                setattr(dataPC0, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
                dataPC1 = Data(pos=pair.pos_target, x=pair.x_target,y=pair.y, idx=torch.arange(pair.pos_target.shape[0]).reshape(-1))
                setattr(dataPC1, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
                dataPC0_cyl = cylinder_sampler(dataPC0)
                dataPC1_cyl = cylinder_sampler(dataPC1)
                try:
                    if self.manual_transform is not None:
                        dataPC0_cyl = self.manual_transform(dataPC0_cyl)
                        dataPC1_cyl = self.manual_transform(dataPC1_cyl)
                    pair_cylinders = Pair(pos=dataPC0_cyl.pos, pos_target=dataPC1_cyl.pos, y=dataPC1_cyl.y,
                                          x=dataPC0_cyl.x, x_target=dataPC1_cyl.x,
                                          idx=dataPC0_cyl.idx, idx_target=dataPC1_cyl.idx, area=area_sel)
                    if self.DA:
                        pair_cylinders.data_augment()
                    pair_cylinders.normalise()
                    pair_correct = True
                except:
                    print('pair not correct')
                    idx += 1
            return pair_cylinders

    def _get_random(self):
        # Random cylinder biased towards getting more low frequency classes
        chosen_label = np.random.choice(self._labels, p=self._label_counts)
        valid_centres = self._centres_for_sampling[self._centres_for_sampling[:, 4] == chosen_label]
        centre_idx = int(random.random() * (valid_centres.shape[0] - 1))
        centre = valid_centres[centre_idx]
        #  choice of the corresponding PC if several PCs are loaded
        area_sel = centre[3].int()
        pair = self._load_save(area_sel)
        cylinder_sampler = CylinderSampling(self._radius, centre[:3], align_origin=False)
        dataPC0 = Data(pos=pair.pos,x=pair.x)
        setattr(dataPC0, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC0)
        dataPC1 = Data(pos=pair.pos_target, x=pair.x_target,y=pair.y)
        setattr(dataPC1, CylinderSampling.KDTREE_KEY, pair.KDTREE_KEY_PC1)
        dataPC0_cyl = cylinder_sampler(dataPC0)
        dataPC1_cyl = cylinder_sampler(dataPC1)
        if self.manual_transform is not None:
            dataPC0_cyl = self.manual_transform(dataPC0_cyl)
            dataPC1_cyl = self.manual_transform(dataPC1_cyl)
        pair_cyl = Pair(pos=dataPC0_cyl.pos, pos_target=dataPC1_cyl.pos, y=dataPC1_cyl.y,
                        x=dataPC0_cyl.x,   x_target=dataPC1_cyl.x, area=area_sel )
        if self.DA:
            pair_cyl.data_augment()
        pair_cyl.normalise()
        return pair_cyl

    def _load_save(self, i):
        if self.pre_transform is not None:
            pc0, pc1, label,x0, x1 = self._preproc_clouds_loader(i)
        else:
            pc0, pc1, label = self.clouds_loader(i, nameInPly=self.nameInPly)
        pair = Pair(pos=pc0, pos_target=pc1, y=label, x=x0, x_target=x1)
        pair = self._get_tree(pair, i)
        return pair

    def _get_tree(self, pair, i):
        path = self.filesPC0[i]
        name_tree = os.path.basename(path).split(".")[0] + "_2D_radius" + str(int(self._radius)) + "_" + str(i) + ".p"
        path_treesPC0 = os.path.join(self.preprocessed_dir, "tp3DTree", name_tree)
        if self.reload_trees and osp.isfile(path_treesPC0):
            try:
                file = open(path_treesPC0, "rb")
                tree = pickle.load(file)
                file.close()
                pair.KDTREE_KEY_PC0 = tree
            except:
                print('not able to load tree')
                print(file)
                print(pair)
                tree = KDTree(np.asarray(pair.pos[:, :-1]), leaf_size=10)
                pair.KDTREE_KEY_PC0 = tree
        else:
            # tree not existing yet should be saved
            # test if tp3D directory is existing
            if not os.path.isdir(os.path.join(self.preprocessed_dir, "tp3DTree")):
                os.makedirs(os.path.join(self.preprocessed_dir, "tp3DTree"))
            tree = KDTree(np.asarray(pair.pos[:, :-1]), leaf_size=10)
            file = open(path_treesPC0, "wb")
            pickle.dump(tree, file)
            file.close()
            pair.KDTREE_KEY_PC0 = tree

        path = self.filesPC1[i]
        name_tree = os.path.basename(path).split(".")[0] + "_2D_radius" + str(int(self._radius)) + "_" + str(i) + ".p"
        path_treesPC1 = os.path.join(self.preprocessed_dir, "tp3DTree", name_tree)
        if self.reload_trees and osp.isfile(path_treesPC1):
            try:
                file = open(path_treesPC1, "rb")
                tree = pickle.load(file)
                file.close()
                pair.KDTREE_KEY_PC1 = tree
            except:
                print('not able to load tree')
                print(file)
                print(pair)
                tree = KDTree(np.asarray(pair.pos_target[:, :-1]), leaf_size=10)
                pair.KDTREE_KEY_PC1 = tree
        else:
            # tree not existing yet should be saved
            # test if tp3D directory is existing
            if not os.path.isdir(os.path.join(self.preprocessed_dir, "tp3DTree")):
                os.makedirs(os.path.join(self.preprocessed_dir, "tp3DTree"))
            tree = KDTree(np.asarray(pair.pos_target[:, :-1]), leaf_size=10)
            file = open(path_treesPC1, "wb")
            pickle.dump(tree, file)
            file.close()
            pair.KDTREE_KEY_PC1 = tree
        return pair


class Urb3DCDDataset(BaseSiameseDataset): #Urb3DCDDataset Urb3DSimulDataset
    """ Wrapper around Semantic Kitti that creates train and test datasets.
        Parameters
        ----------
        dataset_opt: omegaconf.DictConfig
            Config dictionary that should contain
                - root,
                - split,
                - transform,
                - pre_transform
                - process_workers
        """
    INV_OBJECT_LABEL = INV_OBJECT_LABEL
    FORWARD_CLASS = "forward.urb3DSimulPairCyl.ForwardUrb3DSimulDataset"

    def __init__(self, dataset_opt):
        self.pre_transform = dataset_opt.get("pre_transforms", None)
        super().__init__(dataset_opt)
        self.radius = float(self.dataset_opt.radius)
        self.sample_per_epoch = int(self.dataset_opt.sample_per_epoch)
        self.DA = self.dataset_opt.DA
        self.TTA = False
        self.preprocessed_dir = self.dataset_opt.preprocessed_dir
        self.train_dataset = Urb3DSimulCylinder(
            filePaths=self.dataset_opt.dataTrainFile,
            split="train",
            radius=self.radius,
            sample_per_epoch=self.sample_per_epoch,
            DA=self.DA,
            pre_transform=self.pre_transform,
            preprocessed_dir=osp.join(self.preprocessed_dir, "Train"),
            reload_preproc=self.dataset_opt.load_preprocessed,
            reload_trees=self.dataset_opt.load_trees,
            nameInPly=self.dataset_opt.nameInPly,
            fix_cyl=self.dataset_opt.fix_cyl,
            feat_names=self.dataset_opt.get('feat_names', []),
            mufeats_comps=self.dataset_opt.get('mufeats_comps', []),
        )
        self.val_dataset = Urb3DSimulCylinder(
            filePaths=self.dataset_opt.dataValFile,
            split="val",
            radius=self.radius,
            sample_per_epoch= int(self.sample_per_epoch / 2),
            pre_transform=self.pre_transform,
            preprocessed_dir=osp.join(self.preprocessed_dir, "Val"),
            reload_preproc=self.dataset_opt.load_preprocessed,
            reload_trees=self.dataset_opt.load_trees,
            nameInPly=self.dataset_opt.nameInPly,
            fix_cyl=self.dataset_opt.fix_cyl,
            feat_names=self.dataset_opt.get('feat_names', []),
            mufeats_comps=self.dataset_opt.get('mufeats_comps', []),
        )
        self.test_dataset = Urb3DSimulCylinder(
            filePaths=self.dataset_opt.dataTestFile,
            split="test",
            radius=self.radius,
            sample_per_epoch=-1,
            pre_transform=self.pre_transform,
            preprocessed_dir=osp.join(self.preprocessed_dir, "Test"),
            reload_preproc=self.dataset_opt.load_preprocessed,
            reload_trees=self.dataset_opt.load_trees,
            nameInPly=self.dataset_opt.nameInPly,
            feat_names=self.dataset_opt.get('feat_names', []),
            mufeats_comps=self.dataset_opt.get('mufeats_comps', []),
        )

    @property
    def train_data(self):
        if type(self.train_dataset) == list:
            return self.train_dataset[0]
        else:
            return self.train_dataset

    @property
    def val_data(self):
        if type(self.val_dataset) == list:
            return self.val_dataset[0]
        else:
            return self.val_dataset

    @property
    def test_data(self):
        if type(self.test_dataset) == list:
            return self.test_dataset[0]
        else:
            return self.test_dataset

    @staticmethod
    def to_ply(pos, label, file, color=OBJECT_COLOR):
        """ Allows to save Urb3DCD predictions to disk using Urb3DCD color scheme
            Parameters
            ----------
            pos : torch.Tensor
                tensor that contains the positions of the points
            label : torch.Tensor
                predicted label
            file : string
                Save location
            """
        to_ply(pos, label, file, color=color)

    def get_tracker(self, wandb_log: bool, tensorboard_log: bool, full_pc=False, full_res=False):
        """Factory method for the tracker
            Arguments:
                wandb_log - Log using weight and biases
                tensorboard_log - Log using tensorboard
            Returns:
                [BaseTracker] -- tracker
            """
        return Urb3DCDTracker(self, wandb_log=wandb_log, use_tensorboard=tensorboard_log,
                                 full_pc=full_pc, full_res=full_res, ignore_label=IGNORE_LABEL)


################################### UTILS #######################################


def to_ply(pos, label, file, color = OBJECT_COLOR, sf = None):
    """ Allows to save Urb3DCD predictions to disk using Urb3DCD color scheme
       Parameters
       ----------
       pos : torch.Tensor
           tensor that contains the positions of the points
       label : torch.Tensor
           predicted label
       file : string
           Save location
    """
    assert len(label.shape) == 1
    assert pos.shape[0] == label.shape[0]
    pos = np.asarray(pos)
    if max(label)<= color.shape[0]:
        colors = color[np.asarray(label)]
    else:
        colors = color[np.zeros(pos.shape[0], dtype=np.int)]
    if sf is None:
        ply_array = np.ones(
            pos.shape[0],
            dtype=[("x", "f4"), ("y", "f4"), ("z", "f4"), ("red", "u1"),
                   ("green", "u1"), ("blue", "u1"), ("pred", "u2")]
        )
    else:
        ply_array = np.ones(
            pos.shape[0],
            dtype=[("x", "f4"), ("y", "f4"), ("z", "f4"), ("red", "u1"),
                   ("green", "u1"), ("blue", "u1"), ("pred", "u2"), ("sf","f4")]
        )
        ply_array["sf"] = np.asarray(sf)
    ply_array["x"] = pos[:, 0]
    ply_array["y"] = pos[:, 1]
    ply_array["z"] = pos[:, 2]
    ply_array["red"] = colors[:, 0]
    ply_array["green"] = colors[:, 1]
    ply_array["blue"] = colors[:, 2]
    ply_array["pred"] = np.asarray(label)
    el = PlyElement.describe(ply_array, "params")
    PlyData([el], byte_order=">").write(file)
