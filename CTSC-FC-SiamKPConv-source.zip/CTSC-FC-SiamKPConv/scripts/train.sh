#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 ]]; then
  echo 'Usage: bash scripts/train.sh /absolute/path/to/1-Lidar05 [Hydra overrides...]' >&2
  exit 2
fi
dataset_root=$(cd -- "$1" && pwd)
shift
package_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd -- "$package_root"
exec "${PYTHON_BIN:-python}" trainSiamKPConv.py "data.dataset_root=$dataset_root" "$@"
