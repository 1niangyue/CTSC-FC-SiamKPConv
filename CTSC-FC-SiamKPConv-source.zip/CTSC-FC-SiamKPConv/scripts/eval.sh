#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 ]]; then
  echo 'Usage: bash scripts/eval.sh /absolute/path/to/training_run [Hydra overrides...]' >&2
  exit 2
fi
checkpoint_dir=$(cd -- "$1" && pwd)
shift
package_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd -- "$package_root"
exec "${PYTHON_BIN:-python}" eval_SiamKPConv.py "checkpoint_dir=$checkpoint_dir" "$@"
